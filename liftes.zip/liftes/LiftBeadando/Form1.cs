﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace LiftBeadando
{
	public partial class Form1 : Form
	{
		//ha valamit ki akartok iratni, akkor Debug.WriteLine(valami) javasolt;
		//multithread megvan
		public List<Person> displayPeople { get; set; }

		public Building displayHouse { get; set; }

		public List<TextBox> elevationTextBoxes { get; set; }

		public Form1(List<Person> _people, Simulator s, Building house)
		{
			InitializeComponent();
			elevationTextBoxes = new List<TextBox>();
			displayHouse = house;
			displayPeople = _people;
			for (int i = 0; i < s.house.houseSize; i++)
			{
				TextBox dynamicTextBox = new TextBox();
				dynamicTextBox.Size = new System.Drawing.Size(256, 32);
				dynamicTextBox.Top = insidePeopleTextbox.Top - (256 / house.houseSize * (i + 1));
				dynamicTextBox.Left = insidePeopleTextbox.Left;
				dynamicTextBox.Tag = i;
				Controls.Add(dynamicTextBox);
				elevationTextBoxes.Add(dynamicTextBox);
			}
			people_counter_tbox.Text = "People: " + _people.Count() + " House size: " + house.houseSize;
			Task.Run(() => refreshView(_people, s, house));
		}

		private void refreshView(List<Person> people, Simulator s, Building house)
		{
			people = s.updateVisualPeople();
			house = s.updateVisualHouse();
			int insidePeople = 0;
			int outsidePeople = 0;
			int elevatorPeople = 0;
			int counter = 0;
			int peopleOnElevation = 0;
			int peopleOnElevationE = 0;
			while (true)
			{
				insidePeople = 0;
				outsidePeople = 0;
				elevatorPeople = 0;
				counter++;
				try
				{
					List<Person> copiedListForDisplay = s.People.ToList();
					foreach (Person p in copiedListForDisplay)
					{
						//Debug.WriteLine(p.currentState);
						if (p.currentState == Person.State.outsideBuilding)
						{
							outsidePeople++;
						}
						if (p.currentState == Person.State.insideBuilding)
						{
							insidePeople++;
						}
						if (p.currentState == Person.State.inElevator)
						{
							elevatorPeople++;
						}
					}
				// Marshal UI update to the main UI thread
				this.Invoke((MethodInvoker)delegate //neccessary for updating the UI!!! DO NOT TOUCH!!! Form sepcific!
				{
					try
					{
						people_counter_tbox.Text = "Total people left:" + s.totalPeopleLeft;
						outsideTextBox.Text = "People outside: " + outsidePeople;
						insidePeopleTextbox.Text = "people inside(overall): " + insidePeople;
						if (s.house.e.targetHeight>s.house.e.currentHeight)
						{
							label1.Text = "Elevator direction: ^";
						}
						else if (s.house.e.targetHeight < s.house.e.currentHeight) {
							label1.Text = "Elevator direction: ˇ";
						}
						else
						{
							label1.Text = "Elevator direction: =";
						}
						elevatorPanel.Size = new System.Drawing.Size(64, 64);
						elevatorPanel.Top = 288 - ((256 / s.house.e.maxHeight) * (s.house.e.currentHeight));
						elevatorPanel.Left = 160;
						foreach (TextBox tb in elevationTextBoxes)
						{
							peopleOnElevation = 0;
							peopleOnElevationE = 0;
							foreach (Person p in people)
							{
								if (p.currentElevation == (int)tb.Tag && p.currentState.Equals(Person.State.insideBuilding))
								{
									peopleOnElevation += 1;
								}
								if (p.currentElevation == (int)tb.Tag && p.currentState.Equals(Person.State.inElevator))
								{
									peopleOnElevationE += 1;
								}
							}
							tb.Text = "Elevation " + ((int)tb.Tag + 1) + ": " + peopleOnElevation + " elevator: " + peopleOnElevationE;
						}
					}
					catch (Exception e)
					{
						Debug.WriteLine("ERROR:" + e);
						//throw;
					}
				});
				}
				catch (Exception err)
				{
					Debug.WriteLine("ERROR:" + err);
				}
				Thread.Sleep(200);
			}
		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{

		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{

		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{

		}

		private void textBox1_TextChanged_1(object sender, EventArgs e)
		{

		}

		private void panel2_Paint(object sender, PaintEventArgs e)
		{

		}

		private void insidePeopleTextbox_TextChanged(object sender, EventArgs e)
		{

		}

		private void label1_Click(object sender, EventArgs e)
		{

		}
	}
}
