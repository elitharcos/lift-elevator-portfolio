﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace LiftBeadando
{

	public class Person
	{
		public enum State
		{
			outsideBuilding,
			insideBuilding,
			inElevator
		}

		public int currentElevation { get; set; }

		public State currentState { get; set; } = State.outsideBuilding;

		public bool goUp { get; set; } //decides if the person wants to go up or not.
		public bool goDown { get; set; } //decides if the person wants to go down or not.
		public int ID { get; set; }
		public int buildingHeight { get; set; }

		private object peopleLock = new object();

		public Elevator chosenElevator = null; 

		public Person(int personID, int _buildingHeight, Simulator _s)
		{
			buildingHeight = _buildingHeight;
			ID = personID;
			currentState = State.outsideBuilding;
			currentElevation = 0;
			Thread personThread = new Thread(() => move_like_jagger(_s)); //basically decides that the person should do person things, like move in and out, etc.
			personThread.Start();
		}

		private void move_like_jagger(Simulator _s) //act like a person
		{
			Random rnd = new Random();
			int randomseed = 0;
			int peopleInElevator = 0;
			while (true)
			{
				lock (peopleLock)
				{
					if (currentState.Equals(State.outsideBuilding) && rnd.Next(100) < 25)
					{
						_s.removePerson(this);
					}
					if (currentState.Equals(State.outsideBuilding) && rnd.Next(100) < 45)
					{
						currentState = State.insideBuilding;
					}
					else if (currentState.Equals(State.insideBuilding) && rnd.Next(100) < 25 && currentElevation == 0)
					{
						currentState = State.outsideBuilding;
					}
					else if (currentState.Equals(State.insideBuilding) && rnd.Next(100) < 45)
					{
						if (chosenElevator != null)
						{
							if (chosenElevator.currentHeight != currentElevation)
							{
								chosenElevator.callElevator(currentElevation);
							}
							else
							{
								if (chosenElevator.peopleInElevator + 1 <= chosenElevator.weightLimitInPerson)
								{
									currentState = State.inElevator;
									chosenElevator.peopleInElevator++;
								}
							}
						}
					}
					if (rnd.Next(100) > 85 && currentState.Equals(State.insideBuilding))
					{
						randomseed = rnd.Next(buildingHeight); //0-9 base
					}
					if (chosenElevator != null)
					{
						if (chosenElevator.currentHeight == randomseed && currentState.Equals(State.inElevator))
						{
							currentState = State.insideBuilding;
							chosenElevator.peopleInElevator--;
						}
						if (currentElevation == chosenElevator.currentHeight && currentState.Equals(State.inElevator) && currentElevation != randomseed)
						{
							chosenElevator.sendElevator(randomseed);
						}
					}
					if (currentElevation != 0 && !currentState.Equals(State.inElevator))
					{
						Debug.WriteLine(currentState + " in person cycle " + this.ToString() + " target elevation: " + randomseed + " " + currentElevation);
					}
					Thread.Sleep(1000);
				}
			}
		}
		public override string ToString()
		{
			return "Person Elevation:"+currentElevation+" State:"+currentState+" ID:"+ID;
		}
	}
}
