﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LiftBeadando
{
	public partial class Form2 : Form
	{
		public Simulator s { get; set; }

		public Form2(Simulator simulator)
		{
			InitializeComponent();
			s = simulator;
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (int.TryParse(textBox1.Text, out int returnNum))
			{
				s.buildingHeight = returnNum;
			}
			else
			{
				s.buildingHeight = 5;
			}
			this.Close();
		}
	}
}
