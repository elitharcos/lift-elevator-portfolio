﻿
namespace LiftBeadando
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.people_counter_tbox = new System.Windows.Forms.TextBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.elevatorPanel = new System.Windows.Forms.Panel();
			this.insidePeopleTextbox = new System.Windows.Forms.TextBox();
			this.outsideTextBox = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// people_counter_tbox
			// 
			this.people_counter_tbox.Location = new System.Drawing.Point(12, 12);
			this.people_counter_tbox.Name = "people_counter_tbox";
			this.people_counter_tbox.Size = new System.Drawing.Size(150, 20);
			this.people_counter_tbox.TabIndex = 0;
			this.people_counter_tbox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.elevatorPanel);
			this.panel1.Controls.Add(this.insidePeopleTextbox);
			this.panel1.Location = new System.Drawing.Point(378, 45);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(382, 378);
			this.panel1.TabIndex = 1;
			// 
			// elevatorPanel
			// 
			this.elevatorPanel.BackColor = System.Drawing.SystemColors.MenuHighlight;
			this.elevatorPanel.Location = new System.Drawing.Point(195, 239);
			this.elevatorPanel.Name = "elevatorPanel";
			this.elevatorPanel.Size = new System.Drawing.Size(79, 72);
			this.elevatorPanel.TabIndex = 1;
			this.elevatorPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
			// 
			// insidePeopleTextbox
			// 
			this.insidePeopleTextbox.Location = new System.Drawing.Point(17, 330);
			this.insidePeopleTextbox.Name = "insidePeopleTextbox";
			this.insidePeopleTextbox.Size = new System.Drawing.Size(124, 20);
			this.insidePeopleTextbox.TabIndex = 0;
			this.insidePeopleTextbox.TextChanged += new System.EventHandler(this.insidePeopleTextbox_TextChanged);
			// 
			// outsideTextBox
			// 
			this.outsideTextBox.Location = new System.Drawing.Point(207, 403);
			this.outsideTextBox.Name = "outsideTextBox";
			this.outsideTextBox.Size = new System.Drawing.Size(138, 20);
			this.outsideTextBox.TabIndex = 2;
			this.outsideTextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(14, 155);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(35, 13);
			this.label1.TabIndex = 2;
			this.label1.Text = "label1";
			this.label1.Click += new System.EventHandler(this.label1_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.outsideTextBox);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.people_counter_tbox);
			this.Name = "Form1";
			this.Text = "Form1";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox people_counter_tbox;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TextBox outsideTextBox;
		private System.Windows.Forms.TextBox insidePeopleTextbox;
		private System.Windows.Forms.Panel elevatorPanel;
		private System.Windows.Forms.Label label1;
	}
}

