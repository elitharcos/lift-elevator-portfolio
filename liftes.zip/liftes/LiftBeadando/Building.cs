﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace LiftBeadando
{
	public class Building
	{
		private Dictionary<int, List<Person>> peopleInBuildingByElevation = new Dictionary<int, List<Person>>();
		private int v;
		public List<Person> people;

		public Simulator s;

		public int houseSize { get; set; }

		public Elevator e { get; set; }

		private object peopleLock = new object();

		public Building(int _elevationOfHouse, List<Person> _people, Simulator _s)
		{
			s = _s;
			houseSize = _elevationOfHouse;
			e = new Elevator(_elevationOfHouse, 15, this); //the 15 is the person limit;

			//ATTEMPT ONLY:
			//Thread buildingThread = new Thread(() => checkBuilding(_elevationOfHouse, _people, _s));
			//buildingThread.Start();

			//it was planned but unsued, tho still could be
		}

		public Building(int v, List<Person> people)
		{
			this.v = v;
			this.people = people;
		}

		/*
		void checkBuilding(int elevationOfHouse, List<Person> _people, Simulator _s)
		{
			List<Person> peopleToAdd = new List<Person>();
			while (true)
			{
				lock (peopleLock)
				{
					people = _s.updateHouse();
					foreach (Person _person in people)
					{
						if (_person.currentState == Person.State.insideBuilding)
						{
							//Debug.WriteLine("a person is in the building");
						}
					}
					Thread.Sleep(1000);
				}
			}
		}
		*/
	}
}
