﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace LiftBeadando
{
	public class Elevator
	{
		//ha valamit ki akartok iratni, akkor Debug.WriteLine(valami) javasolt;
		//multithread megvan
		public int currentHeight { get; set; }
		public int maxHeight { get; set; }
		public int targetHeight { get; set; }

		public List<Person> people;
		public int weightLimitInPerson { get; set; }
		public bool isMoving { get; set; }

		private object peopleLock = new object();
		public int peopleInElevator { get; set; }

		public System.Timers.Timer aTimer = new System.Timers.Timer();

		public Elevator(int _buildingHeight, int _weightLimitInPerson, Building _b)
		{
			weightLimitInPerson = _weightLimitInPerson;
			maxHeight = _buildingHeight;
			isMoving = false;
			currentHeight = 0;
			Thread elevatorThread = new Thread(() => moveAround(maxHeight, _b));
			elevatorThread.Start();
		}

		private void moveAround(int maxHeight, Building b)
		{
			targetHeight = currentHeight;
			while (true)
			{
				lock (peopleLock)
				{
					people = b.s.updateHouse();
					try
					{
						foreach (Person p in people)
						{
							p.chosenElevator = this;
							if (p.currentState.Equals(Person.State.inElevator))
							{
								p.currentElevation = currentHeight;
							}
						}
						if (targetHeight == currentHeight)
						{
							Thread.Sleep(2000);
							isMoving = false;
						}
						if (isMoving)
						{
							if (targetHeight < currentHeight)
							{
								currentHeight--;
							}
							else if (targetHeight > currentHeight)
							{
								currentHeight++;
							}
						}
						Thread.Sleep(250); //Timer(?)
					}
					catch (Exception e)
					{

					}
				}
			}
		}

		internal void callElevator(int currentElevation)
		{
			if (!isMoving)
			{
				targetHeight = currentElevation;
				isMoving = true;
			}
		}

		internal void sendElevator(int randomseed)
		{
			if (!isMoving)
			{
				targetHeight = randomseed;
				isMoving = true;
			}
		}
	}
}
