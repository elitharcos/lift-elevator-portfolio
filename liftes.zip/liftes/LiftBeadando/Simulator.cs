﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace LiftBeadando
{
	public class Simulator
	{
		public List<Person> People = new List<Person>();

		public Building house = new Building(10, new List<Person>());

		public int totalPeopleLeft { get; set; }

		private object peopleLock = new object();

		public int buildingHeight { get; set; }

		public Simulator()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Form2(this));
			totalPeopleLeft = 0;
			if (buildingHeight == null)
			{
				buildingHeight = 5;
			}
			house = new Building(buildingHeight, People, this);
			Thread personCreateThread = new Thread(() => createPersonByChance(buildingHeight, this));
			personCreateThread.Start();

			Application.Run(new Form1(People, this, house));
			Environment.Exit(Environment.ExitCode);
		}

		private void createPersonByChance(int buildingHeight, Simulator _s)
		{
			Random rnd = new Random();
			int i = 0;
			while (true)
			{
				if (rnd.Next(100) > People.Count())
				{
					People.Add(new Person(i, buildingHeight, _s));
				}
				house.people = People;
				i++;
				Thread.Sleep(1000);
			}
		}

		public List<Person> updateHouse()
		{
			return People;
		}
		public List<Person> updateVisualPeople()
		{
			return People;
		}
		public Building updateVisualHouse()
		{
			return house;
		}

		internal void removePerson(Person person)
		{
			lock (peopleLock)
			{
				People.Remove(person);
				totalPeopleLeft++;
			}
		}
	}
}
